/*
 * Public API Surface of ngx-advance-pagination
 */

export * from './lib/ngx-advance-pagination.component';
export * from './lib/ngx-advance-pagination.module';
